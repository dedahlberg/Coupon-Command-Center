# Coupon Command Center — Step 3

Step 3 adds automatic offer refreshing.

## What changed
- `live-offers.json` is the normalized live offer index.
- `scripts/refresh-offers.cjs` checks public source pages and normalizes eligible public listings.
- `.github/workflows/refresh-offers.yml` runs daily and commits changes automatically.
- `index.html` loads `live-offers.json` first and falls back to `offers.json`.
- Failed source refreshes do not break the site.

## Redemption model
The site indexes public offer information only. It does not generate, alter, duplicate, or bypass coupon barcodes, QR codes, print limits, phone verification, loyalty authentication, or personalized Fetch offers. Redemption remains with the issuing provider.

## Current source strategy
- GrocerySmarts: public directory indexing.
- LOZO: source health/count and authorized link-out.
- Coupons.com: link-out because printable offers use provider verification and print controls.
- Fetch: personalized link-out because offers vary by account.
